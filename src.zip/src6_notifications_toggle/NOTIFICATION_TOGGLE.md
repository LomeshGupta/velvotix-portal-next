# Device Notification Toggle

Every authenticated user now has a per-device notification switch in the Notifications bell.

- **On**: requests browser permission when needed, creates/reuses the PushSubscription, and binds it to the current authenticated user.
- **Off**: removes the current device subscription from the server and unsubscribes it locally. Other devices remain enabled.
- Browser/OS notification permission is not forcibly revoked by the web app; the OS controls that permission. Turning the app toggle back on reuses the permission if it is still granted.
- The existing iOS PWA, Android PWA, desktop push, notification bell, in-app toast, and admin test notification flows remain unchanged.
